"""Redirect route to redirect the user to the external OIDC server,
can either be linked to directly or accessed through the welcome page."""

from urllib.parse import quote

from aiohttp import web
from homeassistant.components.http import HomeAssistantView

from ..stores.state_store import StateStore
from ..tools.helpers import (
    error_response,
    get_url,
    get_valid_state_id,
    template_response,
)
from ..tools.oidc_client import OIDCClient

PATH = "/auth/oidc/redirect"


class OIDCRedirectView(HomeAssistantView):
    """OIDC Plugin Redirect View."""

    requires_auth = False
    url = PATH
    name = "auth:oidc:redirect"

    def __init__(
        self,
        oidc_client: OIDCClient,
        state_store: StateStore,
        force_https: bool,
    ) -> None:
        self.oidc_client = oidc_client
        self.state_store = state_store
        self.force_https = force_https

    async def get(self, req: web.Request) -> web.Response:
        """Receive response."""

        # Get cookie to get the state_id
        state_id = get_valid_state_id(req, self.state_store)

        if not state_id:
            # Direct access to the redirect endpoint, go to welcome page instead
            welcome_url = get_url("/auth/oidc/welcome", self.force_https)
            raise web.HTTPFound(welcome_url)

        try:
            redirect_uri = get_url("/auth/oidc/callback", self.force_https)
            result = await self.oidc_client.async_get_authorization_url(
                redirect_uri, state_id
            )

            if result:
                auth_url, flow = result
                if not self.state_store.set_flow_for_state(state_id, flow, req.remote):
                    return await error_response("invalid_state")

                return await template_response("redirect", {"url": quote(auth_url)})
        except RuntimeError:
            pass

        return await error_response("misconfigured", status=500)

    async def post(self, req: web.Request) -> web.Response:
        """POST"""
        return await self.get(req)
