"""OIDC Integration for Home Assistant."""

import logging
from collections import OrderedDict

from homeassistant.components.http import StaticPathConfig
from homeassistant.config_entries import ConfigEntry
from homeassistant.const import EVENT_HOMEASSISTANT_CLOSE
from homeassistant.core import HomeAssistant
from homeassistant.exceptions import ConfigEntryError

# Get all the constants for the config
from .config import (
    ADDITIONAL_SCOPES,
    CLAIMS,
    CLIENT_ID,
    CLIENT_SECRET,
    DISCOVERY_URL,
    DOMAIN,
    FEATURES,
    FEATURES_DEFAULT_REDIRECT,
    FEATURES_FORCE_HTTPS,
    FEATURES_INCLUDE_GROUPS_SCOPE,
    GROUPS_SCOPE,
    ID_TOKEN_SIGNING_ALGORITHM,
    MAP_GROUPS_TO_ROLES,
    NETWORK,
    REQUIRED_SCOPES,
    ROLES,
    STATIC_FILE_REGISTRATIONS,
    convert_ui_config_entry_to_internal_format,
)

# Import and re-export config schema explicitly for HA
from .config import (
    CONFIG_SCHEMA as CONFIG_SCHEMA,
)
from .endpoints import (
    OIDCCallbackView,
    OIDCDeviceSSE,
    OIDCFinishView,
    OIDCRedirectView,
    OIDCWelcomeView,
)
from .endpoints.auth_providers import take_over_auth_providers
from .endpoints.authorize import take_over_authorize_page
from .provider import OpenIDAuthProvider, has_login_hook
from .stores.state_store import StateStore
from .tools.oidc_client import OIDCClient
from .tools.types import OIDCWelcomeOptions

_LOGGER = logging.getLogger(__name__)


async def async_setup(hass: HomeAssistant, config):
    """Add the OIDC Auth Provider to the providers in Home Assistant (YAML config)."""
    if DOMAIN not in config:
        return True

    my_config = config[DOMAIN]

    # Store YAML config for later access by config flow
    if DOMAIN not in hass.data:
        hass.data[DOMAIN] = {}
    hass.data[DOMAIN]["yaml_config"] = my_config

    await _setup_oidc_provider(hass, my_config)
    return True


async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry):
    """Set up OIDC Authentication from a config entry (UI config)."""
    # A second setup would register the routes and listeners again
    if hass.data.get(DOMAIN, {}).get("yaml_config"):
        raise ConfigEntryError(
            "OIDC is already configured in YAML. "
            + "Remove either the YAML configuration or this entry."
        )

    # Convert config entry data to the format expected by the existing setup
    config_data = entry.data.copy()

    # Convert config entry format to internal format
    my_config = convert_ui_config_entry_to_internal_format(config_data)

    await _setup_oidc_provider(hass, my_config)
    return True


async def async_unload_entry(_hass: HomeAssistant, _entry: ConfigEntry):
    """Unload a config entry."""
    # OIDC auth providers cannot be easily unloaded as they are integrated
    # into Home Assistant's auth system. A restart is required.
    return False


async def _register_oidc_provider(
    hass: HomeAssistant, my_config: dict, state_store: StateStore
):
    """Register the OIDC provider in Home Assistant's auth system."""
    # Use private APIs until there is a real auth platform
    # pylint: disable=protected-access

    providers = OrderedDict()
    provider = OpenIDAuthProvider(hass, hass.auth._store, my_config, state_store)
    await provider.async_initialize()

    existing_auth_providers = hass.auth._providers.copy()
    _LOGGER.debug("Current auth providers: %s", list(existing_auth_providers.keys()))
    auth_provider_count = len(existing_auth_providers)
    has_trusted_networks_provider_first = False

    if auth_provider_count > 0:
        # Pop the first provider from the existing providers to check if it's trusted_networks
        first_provider_key, first_provider_obj = next(
            iter(existing_auth_providers.items())
        )
        existing_auth_providers.pop(first_provider_key)

        if first_provider_key[0] == "trusted_networks":
            _LOGGER.info(
                "Trusted Networks provider detected as the first auth provider. "
                + "Keeping registration order intact."
            )
            providers[first_provider_key] = first_provider_obj
            has_trusted_networks_provider_first = True
        else:
            # Reset back to what we had before
            existing_auth_providers = hass.auth._providers.copy()

    # Register OIDC at the start of the array
    # OIDC needs to be first because it needs to process the login cookie after sign-in
    providers[(provider.type, provider.id)] = provider

    # Add back any other providers that were already registered
    providers.update(existing_auth_providers)

    _LOGGER.debug("Final auth providers: %s", list(providers.values()))
    hass.auth._providers = providers
    # pylint: enable=protected-access

    _LOGGER.info("Registered OIDC provider")
    return provider, has_trusted_networks_provider_first


async def _setup_oidc_provider(hass: HomeAssistant, my_config: dict):
    """Set up the OIDC provider with the given configuration."""
    # pylint: disable=too-many-locals
    state_store = StateStore(hass)
    await state_store.async_remove_legacy_storage()

    provider, has_trusted_networks_provider_first = await _register_oidc_provider(
        hass, my_config, state_store
    )

    # Set the correct scopes
    # Always use 'openid' & 'profile' as they are specified in the OIDC spec
    # All servers should support this
    scope = REQUIRED_SCOPES

    # Include groups if requested (default is to include 'groups'
    # as a scope for Authelia & Authentik)
    features_config = my_config.get(FEATURES, {})
    include_groups_scope = features_config.get(FEATURES_INCLUDE_GROUPS_SCOPE, True)
    groups_scope = my_config.get(GROUPS_SCOPE, "groups")
    if include_groups_scope:
        scope += " " + groups_scope
    # Add additional scopes if configured
    additional_scopes = my_config.get(ADDITIONAL_SCOPES, [])
    if additional_scopes:
        # Ensure we have a space before adding additional scopes
        if scope:
            scope += " "
        scope += " ".join(additional_scopes)

    # Create the OIDC client
    oidc_client = OIDCClient(
        hass=hass,
        discovery_url=my_config[DISCOVERY_URL],
        client_id=my_config[CLIENT_ID],
        scope=scope,
        client_secret=my_config.get(CLIENT_SECRET),
        id_token_signing_alg=my_config.get(ID_TOKEN_SIGNING_ALGORITHM),
        features=my_config.get(FEATURES, {}),
        claims=my_config.get(CLAIMS, {}),
        roles=my_config.get(ROLES, {}),
        network=my_config.get(NETWORK, {}),
        map_groups_to_roles=my_config.get(MAP_GROUPS_TO_ROLES, True),
    )
    hass.bus.async_listen_once(EVENT_HOMEASSISTANT_CLOSE, oidc_client.async_close)

    # Register the views
    force_https = features_config.get(FEATURES_FORCE_HTTPS, False)
    default_redirect = features_config.get(FEATURES_DEFAULT_REDIRECT, False)

    # Register the static paths
    for url_path, (file_path, cache_headers) in STATIC_FILE_REGISTRATIONS.items():
        await hass.http.async_register_static_paths(
            [StaticPathConfig(url_path, file_path, cache_headers)]
        )

    hass.http.register_view(
        OIDCWelcomeView(
            provider,
            state_store,
            OIDCWelcomeOptions(
                force_https=force_https,
                prefers_skipping=default_redirect,
            ),
        )
    )
    hass.http.register_view(OIDCDeviceSSE(state_store))
    hass.http.register_view(OIDCRedirectView(oidc_client, state_store, force_https))
    hass.http.register_view(
        OIDCCallbackView(oidc_client, provider, state_store, force_https)
    )
    hass.http.register_view(OIDCFinishView(state_store))

    _LOGGER.info("Registered OIDC views")

    take_over_authorize_page(
        hass, provider, force_https, has_trusted_networks_provider_first
    )

    # Newer Home Assistant versions ask the provider itself if it can be offered
    if not has_login_hook():
        take_over_auth_providers(hass, provider)

    return True
